These files were created in Design Spark Open Source Schematic Layout Software 
http://www.designspark.com/
You will need to copy the contents of DesignSparkLibraryFiles into the default Library that Design Spark uses. Normally something like Documents\DesignSpark PCB\Library
This is the only way you will be able to use or modify the APDS-9008 part or the reverse mount LED part.


CONTRIBUTORS BACKTRACK AND NOTIFICATION

joel@joelmurphy.net
yury.gitman@gmail.com

Licensed under the TAPR Open Hardware License (www.tapr.org/OHL)